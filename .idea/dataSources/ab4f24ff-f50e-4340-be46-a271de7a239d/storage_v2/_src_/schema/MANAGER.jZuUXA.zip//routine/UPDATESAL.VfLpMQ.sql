CREATE procedure updateSal(eno emp.empno%type)
  is
begin
  update emp set sal=sal+100 where empno=eno;
  commit;
end;
/

