CREATE TRIGGER T1
  AFTER INSERT
  ON PERSON
  declare

 begin
   dbms_output.put_line('一个人出发了这个函数');
 end;
/

