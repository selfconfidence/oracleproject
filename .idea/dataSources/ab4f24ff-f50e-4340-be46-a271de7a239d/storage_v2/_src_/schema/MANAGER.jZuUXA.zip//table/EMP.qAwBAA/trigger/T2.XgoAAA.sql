CREATE TRIGGER T2
  BEFORE UPDATE
  ON EMP
  FOR EACH ROW
  declare
    begin
      if :old.sal>:new.sal then
        raise_application_error(-20501,'不能给员工降薪');
        end if;
        end;
/

