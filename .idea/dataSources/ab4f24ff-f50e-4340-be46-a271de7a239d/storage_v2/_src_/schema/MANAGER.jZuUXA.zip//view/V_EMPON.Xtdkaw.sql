CREATE VIEW V_EMPON AS
  select ename,job,sal from emp with read only
/

