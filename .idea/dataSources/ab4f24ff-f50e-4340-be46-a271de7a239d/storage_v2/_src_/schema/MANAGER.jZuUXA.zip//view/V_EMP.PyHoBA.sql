CREATE VIEW V_EMP AS
  select ename,job  from emp
/

