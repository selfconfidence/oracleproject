CREATE function f_dname(did dept.deptno%type) return  dept.dname%type
 is
     d_name dept.dname%type;
 begin
   select dname into d_name from dept where deptno=did;
   return d_name;
 end;
/

